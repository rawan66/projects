//
//  File.swift
//  Calculator
//
//  Created by Rawan Fahad on ٢٦‏/١‏/٢٠١٩.
//  Copyright © ٢٠١٩ London App Brewery. All rights reserved.
//

import Foundation


class Test{
    let viewController = ViewController()
    
    init() {
        
        viewController.isfinishedTypingNumber = true
    }
}
