//
//  SkillVC.swift
//  welcome
//
//  Created by Rawan Fahad on ٢٩‏/١‏/٢٠١٩.
//  Copyright © ٢٠١٩ Rawan Fahad. All rights reserved.
//

import UIKit

class SkillVC: UIViewController  {
    
    var Player : player!

    @IBOutlet weak var finsh1: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

print(Player.desiredLeague)
        
    }
    
    
    @IBAction func Begir(_ sender: Any) {
        select(legueTyp: "Beir")
    }
    
    
    
    @IBAction func baller(_ sender: Any) {
        select(legueTyp: "baller")
    }
    

    func select(legueTyp : String){
        Player.desiredLeague = legueTyp
        finsh1.isEnabled = true
        
    }
    
    
    @IBAction func finsh(_ sender: Any) {
        exit(0)
    }
    
    
    
    }



