//
//  ViewController.swift
//  welcome
//
//  Created by Rawan Fahad on ٢٨‏/١‏/٢٠١٩.
//  Copyright © ٢٠١٩ Rawan Fahad. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var swoosh: UIImageView!
    
    @IBOutlet var bgimg: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()

    }


}

