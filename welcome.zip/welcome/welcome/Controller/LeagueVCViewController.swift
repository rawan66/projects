//
//  LeagueVCViewController.swift
//  welcome
//
//  Created by Rawan Fahad on ٢٩‏/١‏/٢٠١٩.
//  Copyright © ٢٠١٩ Rawan Fahad. All rights reserved.
//

import UIKit

class LeagueVCViewController: UIViewController {
    
    var Player : player!

    @IBOutlet weak var nextBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        Player = player()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func back(_ sender: Any) {
        performSegue(withIdentifier : "fd", sender: self)

    }
    
     @IBAction func onNextTapped(_ sender: Any) {
       performSegue(withIdentifier : "skillVCSegue", sender: self)

    }
    
    
    @IBAction func onMensTapped(_ sender: Any) {
        selectLeague(leagueType: "mens")
        
    }
    
    @IBAction func onWomensTapped(_ sender: Any) {
        selectLeague(leagueType: "womens")
    }
    
    @IBAction func onCoedTapped(_ sender: Any) {
        selectLeague(leagueType: "coed")
    }
    
    func selectLeague(leagueType : String){
        Player.desiredLeague = leagueType
        nextBtn.isEnabled = true
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let skillVC = segue.destination as? SkillVC {
            skillVC.Player = Player
            
        }
        
    }
}
