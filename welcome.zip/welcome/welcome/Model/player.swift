//
//  player.swift
//  welcome
//
//  Created by Rawan Fahad on ٢٩‏/١‏/٢٠١٩.
//  Copyright © ٢٠١٩ Rawan Fahad. All rights reserved.
//

import Foundation

struct player {
    var desiredLeague : String!
    var selectedSkillLevel : String!
}
