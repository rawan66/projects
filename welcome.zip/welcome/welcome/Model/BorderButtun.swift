//
//  BorderButtun.swift
//  welcome
//
//  Created by Rawan Fahad on ٢٨‏/١‏/٢٠١٩.
//  Copyright © ٢٠١٩ Rawan Fahad. All rights reserved.
//

import UIKit

class BorderButtun: UIButton {

    override func awakeFromNib() {
        super.awakeFromNib()
        layer.borderWidth = 3.0
        layer.borderColor = UIColor.white.cgColor
    }

}
